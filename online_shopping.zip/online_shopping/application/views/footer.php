<div class="fixed-bottom bg-info footer">
<p class="p-4 text-center text-white">
	All rights reserved &copy; - Designed by R.Ganesh kumar
</p>
</div>
